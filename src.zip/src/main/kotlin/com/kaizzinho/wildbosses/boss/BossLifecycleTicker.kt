package com.kaizzinho.wildbosses.boss

import com.cobblemon.mod.common.entity.pokemon.PokemonEntity
import com.kaizzinho.wildbosses.config.WildBossesConfig
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents
import net.minecraft.server.level.ServerLevel

object BossLifecycleTicker {

    private const val CHECK_INTERVAL_TICKS = 20L

    private var tickCounter = 0L

    fun register() {
        ServerTickEvents.END_SERVER_TICK.register { server ->
            tickCounter++
            if (tickCounter % CHECK_INTERVAL_TICKS != 0L) return@register

            val currentTick = server.overworld().gameTime
            val expired = BossRegistry.allBosses().filter { instance ->
                !instance.defeated &&
                    currentTick - instance.spawnedAtTick >= WildBossesConfig.data.bossLifetimeTicks
            }

            for (instance in expired) {
                var found: PokemonEntity? = null
                var foundLevel: ServerLevel? = null
                for (level in server.allLevels) {
                    val entity = level.getEntity(instance.entityUuid)
                    if (entity is PokemonEntity) {
                        found = entity
                        foundLevel = level
                        break
                    }
                }

                if (found == null || found.isRemoved) {
                    continue
                }

                BossDepartureMessages.announceLifetimeExpired(
                    server,
                    instance,
                    found.pokemon.species.name
                )
                found.discard()

                server.scoreboard.removePlayerFromTeam(instance.entityUuid.toString())
                BossRegistry.unregister(instance.entityUuid)
                foundLevel?.let { BossPersistence.requestLevelCheckpoint(it) }
            }
        }
    }
}
